package array;


class EmployeeSal{
int bonus;
public void CalSalary(int salary) {
	int finalsalary = salary+ bonus;
	System.out.println("final salary"+ finalsalary);
}
	
}

class ContractEmp extends EmployeeSal{
public ContractEmp() {
	bonus = 4000;
}

}
class PerEmployee extends EmployeeSal{
public PerEmployee() {
	bonus=6000;
}

}


public class Arr_main {
public static void main(String[] args) {
EmployeeSal emp1 = new ContractEmp();
emp1.CalSalary(4000);
EmployeeSal emp2 = new ContractEmp();
emp2.CalSalary(6000);

}
}
