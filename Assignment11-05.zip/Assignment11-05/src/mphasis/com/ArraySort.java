package mphasis.com;
import java.util.Scanner;
import java.util.Arrays;
public class ArraySort {
	public static void main(String[] args) {
		int[]arr= {1,2,3,6,7};
		Scanner input = new Scanner(System.in);
		System.out.println("enter the value of n:");
		int n = input.nextInt();
		int nhighest = getNHighest(arr,n);
		System.out.println("nth highest number"+nhighest);
	}
	public static int getNHighest(int[] arr, int n) {
		Arrays.sort(arr);
		return arr[arr.length-n];
	}
	

}
