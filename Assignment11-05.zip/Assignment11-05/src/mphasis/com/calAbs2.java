package mphasis.com;

public interface calAbs2 {
	
		
			public abstract void substraction(int num1,int num2);
			
			
}
