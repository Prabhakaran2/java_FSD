package mphasis.com;



public class ArrayEx {
public static void main(String[] args) {
	int arr[]= {2,6,7,8};  
	ArrayEx.DisplayArray(arr);
}
	public static void DisplayArray(int arr[]) {
		for (int i=0;i<arr.length;i++) {
			System.out.println(arr[i]+"");
		}
	}
	  

}
//
