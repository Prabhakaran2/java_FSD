package mphasis.com;
public class Exmain {
public static void main(String[] args) {
	Callmp imp=new Callmp();
	imp.addition(2, 3);
	Callmp imp1 = new Callmp();
	imp.substraction(4,2);
}
}



 



