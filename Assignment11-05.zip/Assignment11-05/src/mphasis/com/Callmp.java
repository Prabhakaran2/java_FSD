package mphasis.com;

public class Callmp implements calAbs1,calAbs2{

	@Override
	public void addition(int num1, int num2) {
		// TODO Auto-generated method stub
		System.out.println("the addtition is "+(num1+num2));
	}

	@Override
	public void substraction(int num1, int num2) {
		// TODO Auto-generated method stub
		System.out.println("the sub is "+(num1-num2));
	}

	
	
}
