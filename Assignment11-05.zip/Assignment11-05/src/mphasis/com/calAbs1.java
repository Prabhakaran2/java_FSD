package mphasis.com;


//menu of methods
interface calAbs1  {
//abstract methods : methods without body.
	public abstract void addition(int num1,int num2);
		
}






