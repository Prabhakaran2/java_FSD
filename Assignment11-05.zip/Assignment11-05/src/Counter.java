class Counter{
	int counter=0;
	static int counter2=0;
	Counter(){
		counter++;
		counter2++;
		System.out.println("counter "+counter+" counter2 "+counter2);
	}
	
}
public class Countermain{
public static void main(String[] args) {
	Counter count1=new Counter();
	Counter count2=new Counter();
	Counter count3=new Counter();
	
}
}
