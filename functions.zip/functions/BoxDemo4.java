package functions;
import java.util.*;

// with arugument without return type

class Box4{
	double height;
	double breadth;
	double length;
	
	void volumebox4() {
		System.out.println( "The volume of the box4 is "+ height*breadth*length  );
		
	}
}
public class BoxDemo4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Box4 box4obj = new Box4();
		System.out.println("Enter the Breadth :");
		box4obj.breadth = sc.nextDouble();
		System.out.println("Enter the Length :");
		box4obj.length = sc.nextDouble();
		System.out.println("Enter the Heigth :");
		box4obj.height = sc.nextDouble();
		
		box4obj.volumebox4();
		
		
	}

}
