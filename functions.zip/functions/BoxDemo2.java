package functions;
import java.util.*;
//without Arguments with Return Type

class box2{
	double length;
	double breadth;
	double height;
	
    double boxvolume2() {
		return length*breadth*height;
	}

}


public class BoxDemo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		box2 box2obj = new box2();
		System.out.println("Enter the Breadth :");
		box2obj.breadth = sc.nextDouble();
		System.out.println("Enter the Length :");
		box2obj.length = sc.nextDouble();
		System.out.println("Enter the Heigth :");
		box2obj.height = sc.nextDouble();
		
		double volume = box2obj.boxvolume2();
		System.out.println("The volume of the box2 is "+ volume);
		
	}

}
