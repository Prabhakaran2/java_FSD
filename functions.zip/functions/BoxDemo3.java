package functions;
import java.util.*;
//without Argument Without Return type

class box3{
	double length;
	double breadth;
	double height;
	
    void box3volume() {
    	
    	System.out.println("The volume of the box3 is " + length*breadth*height);
    	
    }

}
public class BoxDemo3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		box3 box3obj = new box3();
		System.out.println("Enter the Breadth :");
		box3obj.breadth = sc.nextDouble();
		System.out.println("Enter the Length :");
		box3obj.length = sc.nextDouble();
		System.out.println("Enter the Heigth :");
		box3obj.height = sc.nextDouble();
		
		box3obj.box3volume();
		
		
	}

	

}
