package functions;
import java.util.*;
class box1{
	
	// with Arguments with Return Type
    double boxvolume1(double length,double breath,double height) {
		return length*breath*height;
	}

}

public class BoxDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		box1 box1obj = new box1();
		System.out.println("Enter the Breadth :");
		double breath= sc.nextDouble();
		System.out.println("Enter the Length :");
		double length= sc.nextDouble();
		System.out.println("Enter the Heigth :");
		double heigh= sc.nextDouble();
		
		double volume = box1obj.boxvolume1(length, breath, heigh);
		System.out.println("Volume of the Box1 is "+ volume);
	}

}
